var express = require('express')
var cors = require('cors')
var app = express()

app.use(express.json())
app.use(cors())

app.get('/hello', (req, res) => {
    let q = req.query
    res.json({
        q
    })
});


app.post('/hello', (req, res) => {
    console.log(req.body)
    res.json(req.body)
})

app.listen(3004)

console.log('listenign on 3004')